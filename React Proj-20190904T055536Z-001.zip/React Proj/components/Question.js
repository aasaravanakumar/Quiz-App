import React from "react";
import { View, Text, StyleSheet, Button, Image, Alert } from "react-native";
//import { RadioGroup, RadioButton } from "react-native-flexi-radio-button";
import RadioForm, {RadioButton, RadioButtonInput, RadioButtonLabel} from 'react-native-simple-radio-button';

export default class Question extends React.Component {
  constructor() {
    super();
	this.reset();
	this.selectedIndex = -1;
  }

  reset() {
	this.state = {
      answer: null,
	  index : 0
    };
  }
  
  renderOptions = question => {
      const radio_props = [];
		question.options.forEach((item, index) => {
			radio_props.push(
			  {label: item, value: index},
			);
		});
	  
        /* result.push(
		{ <RadioButton value={item} key={Math.floor(Math.random() * 10000)} onSelect={(index, answer) => this.setState({ answer, index })}>
				<Text style={styles.radioText}>{item}</Text>
		</RadioButton>} */
		return(
			<View>
				<RadioForm
				  radio_props={radio_props}
				  initial={this.selectedIndex}
				  //onPress={(label,value) => {this.setState({label, value})}}
				  onPress={(value) => {this.setState({value:value})}}
				/>
			</View>
		);
        {
		//);
		//return result;
		}
    //}
  };  

  render() {
    return (
      <View style={{ flex: 1, padding: 12 }}>
        <Text style={{ fontSize: 16, color: "#666", textAlign: "right" }}>
			{this.props.current + 1} out of {this.props.total}
        </Text>
		{
			(this.props.question.imgQues!='')&&(
				<Image
				  style={{width: 200, height: 200}}
				  source={{uri:	`data:image/jpeg;base64,${this.props.question.imgQues}`}}
				/>
			)
		}
		<Text style={{ fontSize: 32, fontWeight: "bold", color: "#3498db" }}>
			{this.props.question.ques}
		</Text>
	  {this.renderOptions(this.props.question)}
        {/* <RadioGroup
          onSelect={(index, answer) => this.setState({ answer, index })}
		  selectedIndex={-1}
        > */}
			  {//</RadioGroup>
			  }
		<View style={{display: "flex", flexDirection: "row", padding: 12}}>
			{/* <Button
			  title="Prev"
			  onPress={() => {
				this.props.onSelect(this.state,"<");
				this.selectedIndex=null;
				this.reset();
			  }}
			/> */}
			<View style={{marginLeft:"auto",marginRight:"auto"}}></View>
			<Button
			  title={this.props.current + 1 == this.props.total?"Submit":"Next"}
			  onPress={() => {
				this.props.onSelect(this.state,(this.props.current + 1 == this.props.total)?"=":">");
				this.selectedIndex=-1;
				this.reset();
			  }}
			/>
		</View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  radioText: {
    fontSize: 20
  }
});
