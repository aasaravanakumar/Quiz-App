import React from "react";
import {
  StyleSheet,
  Text,
  View,
  Image,
  Button,
  ActivityIndicator,
  TextInput
} from "react-native";
import Questions from "./Questions";
import { Link } from "react-router-native";
import { Ionicons } from "@expo/vector-icons";

export default class App extends React.Component {
	constructor(props) {
		super(props);
		this.state = { text: '' };
	}
  
  render() {
    return (
      <View style={styles.container}>
        <Image
          source={require("../assets/logo.png")}
          style={{ width: 200, height: 85 }}
        />
        <Text style={styles.welcome}>WELCOME TO QUIZ APP</Text>
		<TextInput
			style={{height: 40, borderColor: 'gray', borderWidth: 1, padding:10, borderRadius:10, marginTop:10, width:200}}
			onChangeText={(text) => this.setState({text})}
			value={this.state.text}
		/>
        <Text style={styles.paragraph}>
          Enter your user id to start the quiz. If you taken the test already wait for another quiz to launch.
        </Text>
        <Link to={{pathname:'/questions',params:{ id: this.state.text }}} underlayColor="#f0f4f7" disabled={this.state.text==''} style={this.state.text==''?styles.disbutton:styles.button}>
          <View style={{ display: "flex", flexDirection: "row" }}>
            <Ionicons name="md-play" size={32} color="white" />
            <Text
              style={{
                color: "white",
                fontWeight: "bold",
                marginLeft: 10,
                marginTop: 5
              }}
            >
              Start Quiz
            </Text>
          </View>
        </Link>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "center"
  },

  welcome: {
    fontSize: 22,
    fontWeight: "bold",
    backgroundColor: "#3498db",
    color: "white",
    padding: 10
  },

  button: {
    backgroundColor: "#3498db",
    padding: 10,
    borderRadius: 10
  },
  disbutton: {
    backgroundColor: "grey",
    padding: 10,
    borderRadius: 10
  },

  paragraph: {
    fontSize: 16,
    color: "#777",
    textAlign: "center",
    padding: 10,
    marginTop: 15,
    lineHeight: 25
  }
});
