import React from "react";
import {
  View,
  Text,
  ActivityIndicator,
  StyleSheet,
  Picker,
  Button,
  Alert,
  AsyncStorage
} from "react-native";
import { Link } from "react-router-native";
import Question from "../components/Question";

export default class Questions extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      loading: false,
      questions: [],

      current: 0,
      correctScore: 5,
      totalScore: 50,

      results: {
        score: 0,
        correctAnswers: 0
      },
      completed: false
    };
  }

  fetchQuestions = async () => {
    await this.setState({ loading: true });/* 
    const response = await fetch(
      `https://opentdb.com/api.php?amount=10&difficulty=medium`
    ); 
    const questions = await response.json();
    const { results } = questions;
	*/
    const questions = require("./ques.json");

    const results = questions;

    results.forEach(item => {
      item.id = Math.floor(Math.random() * 10000);
    });

    await this.setState({ questions: results, loading: false });
  };

  reset = () => {
    this.setState(
      {
        questions: [],
        current: 0,
        results: {
          score: 0,
          correctAnswers: 0
        },
        completed: false,
        completedAlready: false
      },
      () => {
        this.fetchQuestions();
      }
    );
  };

  moveQuesn = (index, state, dir) => {
    const question = this.state.questions[index];
    const isCorrect = state.value+1==question.ans;
    const results = { ...this.state.results };
	
	if(state.value==undefined) {
		Alert.alert(
         'Answer the question...'
		)
		return;
	} else {
		results.score = isCorrect ? results.score + 1 : results.score;			
		/* state.index = 0;
		state.answer = null; */
	}
    results.correctAnswers = isCorrect
      ? results.correctAnswers + 1
      : results.correctAnswers;

	if(dir=="<") {
		if(this.state.current!=0) {
			this.setState({
			  current: index - 1,
			  results
			});
		}
	} else if(dir==">") {
		if(this.state.current+1!=this.state.questions.length) {
			this.setState({
			  current: index + 1,
			  results
			});
		}
	} else {
		AsyncStorage.getItem("user", (err, result) => {
			AsyncStorage.setItem(result, results.score+"", () => {
			});
		});
		this.setState({
			completed:true,
			results
		});
	}
  };

  componentDidMount() {
    this.fetchQuestions();
	const userId = this.props.location.params.id;
	AsyncStorage.getItem(userId, (err, result) => {
		if(result!=null && result != '') {
			this.setState({
				completed:true,
				completedAlready:true
			});
		}
	});
	AsyncStorage.setItem("user", userId, () => {
	});
	
  }

  render() {
    return (
      <View style={styles.container}>
        {!!this.state.loading && (
          <View style={styles.loadingQuestions}>
            <ActivityIndicator size="large" color="#00ff00" />
            <Text>Please wait while we are loading questions for you</Text>
          </View>
        )}

        {!!this.state.questions.length > 0 &&
          this.state.completed === false && (
				<Question
				  onSelect={(state,dir) => {
					this.moveQuesn(this.state.current, state, dir);
				  }}
				  question={this.state.questions[this.state.current]}
				  correctPosition={Math.floor(Math.random() * 3)}
				  current={this.state.current}
				  total={this.state.questions.length}
				/>
          )}

        <View
          style={{ flex: 1, alignItems: "center", justifyContent: "center" }}
        >
          {this.state.completed === true && (
            <View style={{ alignItems: "center" }}>
              <Text style={{ fontSize: 35 }}>Quiz Completed</Text>
				  {/* <Text>Correct Answers: {this.state.results.correctAnswers}</Text>
              <Text>
                Incorrect Answers: {10 - this.state.results.correctAnswers}
              </Text>
		  <Text>Total Score: {50}</Text> 
              <Text>Obtained Score: {this.state.results.score}</Text>*/}
				  {this.state.completedAlready && (
					<Text style={{ fontSize: 20, marginTop:10 }}>
						You have completed the test already...
					</Text>
				  )}
				<Link to='/'>
					<Text style={{ fontSize: 25, padding:10, borderRadius:10, backgroundColor: "#3498db", marginTop:10, color:"white" }}>Home</Text>
				</Link>
            </View>
          )}
        </View>
      </View>
    );
  }

}

const styles = StyleSheet.create({
  container: {
    display: "flex",
    height: "100%"
  },

  loadingQuestions: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center"
  }
});
